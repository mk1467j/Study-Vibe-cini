import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Home, Book, Layers, CheckSquare, Music, BarChart3, Settings, Menu, 
  LogOut, Coffee, ShieldCheck, HelpCircle, Cloud, CloudOff, RefreshCw, 
  KeyRound, GraduationCap, Sparkles, Pin, PinOff, Compass, Maximize2, Minimize2, X, ChevronRight, CircleDot
} from 'lucide-react';
import { useAppStore } from '@/store/useAppStore';
import { cn } from '@/lib/utils';
import { Outlet, Link, useRouterState, useLocation, useNavigate } from '@tanstack/react-router';
import { useAuth } from '@/context/AuthContext';
import { PDFSidebarPanel } from '../PDFSidebar/PDFSidebar';
import { FloatingPomodoro } from '../widgets/FloatingPomodoro';


const NAV_ITEMS = [
  { icon: Home, label: 'Dashboard', path: '/' },
  { icon: GraduationCap, label: 'My Batch', path: '/batch' },
  { icon: Book, label: 'Notes', path: '/notes' },
  { icon: Layers, label: 'Tools', path: '/tools' },
  { icon: Coffee, label: 'Focus', path: '/focus' },
  { icon: CheckSquare, label: 'Tasks', path: '/tasks' },
  { icon: Music, label: 'Music', path: '/music' },
  { icon: BarChart3, label: 'Analytics', path: '/analytics' },
];

export function AppLayout() {
  const { sidebarCollapsed, toggleSidebar } = useAppStore();
  const location = useLocation();
  const navigate = useNavigate();
  const { user, guestUser, isGuest, logout, loading } = useAuth();
  const currentUserId = user?.id || guestUser?.id || 'guest_default';

  // Hover & lock state for the spatial launcher sidebar
  const [isHovered, setIsHovered] = useState(false);
  const [isSidebarLocked, setIsSidebarLocked] = useState(() => {
    const saved = localStorage.getItem('studyvibe_sidebar_locked');
    return saved !== null ? JSON.parse(saved) : false;
  });

  // Mobile Spatial Orb Menu State
  const [isMobileHubOpen, setIsMobileHubOpen] = useState(false);

  // Fullscreen / standalone App Mode tracking state
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(document.fullscreenElement !== null);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
      } else if (document.exitFullscreen) {
        await document.exitFullscreen();
      }
    } catch (err) {
      console.warn("Fullscreen API not allowed or supported in this workspace: ", err);
    }
  };

  // Expanded calculated state
  const isExpanded = isSidebarLocked || isHovered;

  // Real-time background screen-time tracker hook
  useEffect(() => {
    const isGuestUser = currentUserId.startsWith('guest_') || currentUserId === 'guest_default';
    const storageKey = `studyvibe_web_screentime_${currentUserId}`;
    
    const existing = localStorage.getItem(storageKey);
    if (!existing) {
      localStorage.setItem(storageKey, isGuestUser ? '7420' : '0');
    }

    const interval = setInterval(() => {
      if (document.visibilityState === 'visible') {
        const currentVal = Number(localStorage.getItem(storageKey) || 0);
        localStorage.setItem(storageKey, String(currentVal + 1));
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [currentUserId]);

  useEffect(() => {
    localStorage.setItem('studyvibe_sidebar_locked', JSON.stringify(isSidebarLocked));
  }, [isSidebarLocked]);

  // Route-protection guard
  React.useEffect(() => {
    if (!loading && !user && !isGuest && location.pathname !== '/auth') {
      navigate({ to: '/auth' });
    }
  }, [user, isGuest, loading, location.pathname, navigate]);

  // Handle cinematic auth screen bypass
  if (location.pathname === '/auth') {
    return (
      <div className="min-h-screen relative overflow-x-hidden flex items-center justify-center bg-black w-full text-white">
        <Outlet />
      </div>
    );
  }

  // Handle cinematic immersive study mode bypass
  if (location.pathname === '/study') {
    return <Outlet />;
  }

  // Handle loading states securely
  if (loading) {
    return (
      <div className="min-h-screen relative flex flex-col items-center justify-center bg-[#050510] text-gray-400 gap-4">
        <div className="w-12 h-12 rounded-full border-t-2 border-brand-purple border-r-2 border-transparent animate-spin" />
        <p className="font-mono text-xs tracking-widest uppercase text-brand-purple">Loading your study workspace...</p>
      </div>
    );
  }

  // Auth Display Profile Helpers
  const getInitials = () => {
    if (user) {
      const name = user.user_metadata?.full_name || user.email || 'S';
      return name.substring(0, 2).toUpperCase();
    }
    if (guestUser) {
      return guestUser.name.substring(0, 2).toUpperCase();
    }
    return 'SV';
  };

  const getEmail = () => {
    if (user) return user.email || 'scholar@studyvibe.co';
    if (guestUser) return guestUser.email || 'guest@studyvibe.local';
    return '';
  };

  const getName = () => {
    if (user) return user.user_metadata?.full_name || 'Student';
    if (guestUser) return guestUser.name || 'Guest Learner';
    return 'Learner';
  };

  const getAvatarUrl = () => {
    if (user) {
      return user.user_metadata?.avatar_url || `https://api.dicebear.com/7.x/notionists/svg?seed=${user.email || 'Study'}`;
    }
    if (guestUser) {
      return guestUser.avatar_url;
    }
    return 'https://api.dicebear.com/7.x/notionists/svg?seed=Study';
  };
  const getPageTitle = () => {
    const item = NAV_ITEMS.find(item => item.path === location.pathname);
    if (item) return item.label;
    if (location.pathname === '/settings') return 'Preferences';
    return 'StudyVibe';
  };

  const showExpandedContent = isExpanded || isMobile;

  const mainContent = (
    <div className="min-h-[100dvh] flex relative w-full overflow-x-hidden">
      {/* Premium Mobile Top Header Bar */}
      {isMobile && (
        <div className="fixed top-0 left-0 right-0 h-[64px] z-30 border-b border-white/5 bg-[#050510]/80 backdrop-blur-2xl flex items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMobileSidebarOpen(true)}
              className="p-2 rounded-xl border border-white/10 bg-white/5 text-gray-400 hover:text-white hover:border-white/20 transition-all flex items-center justify-center cursor-pointer active:scale-95"
            >
              <Menu className="w-5 h-5" />
            </button>
            <span className="font-serif font-semibold italic text-white text-base tracking-wide">
              {getPageTitle()}
            </span>
          </div>
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-brand-purple to-brand-indigo flex items-center justify-center shadow-[0_0_10px_rgba(139,92,246,0.3)]">
            <span className="font-serif font-extrabold text-white text-[10px]">SV</span>
          </div>
        </div>
      )}

      {/* Blurred Backdrop for Mobile Sidebar Drawer */}
      <AnimatePresence>
        {isMobile && isMobileSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsMobileSidebarOpen(false)}
            className="fixed inset-0 z-30 bg-black/70 backdrop-blur-sm"
          />
        )}
      </AnimatePresence>

      {/* Responsive Sidebar for both Mobile and Desktop */}
      <motion.aside
        onMouseEnter={() => !isMobile && setIsHovered(true)}
        onMouseLeave={() => !isMobile && setIsHovered(false)}
        initial={{ width: 68 }}
        animate={{ 
          width: isMobile ? 240 : (isExpanded ? 240 : 84),
          x: isMobile ? (isMobileSidebarOpen ? 0 : -280) : 0
        }}
        transition={{ type: "spring", stiffness: 320, damping: 28 }}
        className="flex flex-col fixed left-2.5 top-2.5 bottom-2.5 md:left-4 md:top-4 md:bottom-4 z-40 rounded-[24px] md:rounded-[32px] border border-white/10 bg-[#050510]/90 backdrop-blur-3xl shadow-[0_30px_60px_rgba(0,0,0,0.85)] select-none overflow-hidden group/sidebar"
      >
        <div className="p-3.5 md:p-5 flex items-center justify-between w-full border-b border-white/[0.06] shrink-0">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-brand-purple to-brand-indigo flex items-center justify-center shadow-[0_0_15px_rgba(139,92,246,0.35)] shrink-0">
              <span className="font-serif font-extrabold text-white text-xs">SV</span>
            </div>
            
            <AnimatePresence>
              {showExpandedContent && (
                <motion.span
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  className="font-serif font-semibold text-white text-xs tracking-wide whitespace-nowrap"
                >
                  StudyVibe OS
                </motion.span>
              )}
            </AnimatePresence>
          </div>

          <AnimatePresence>
            {showExpandedContent && (
              <div className="flex items-center gap-1 shrink-0">
                {isMobile ? (
                  <button
                    onClick={() => setIsMobileSidebarOpen(false)}
                    className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                ) : (
                  <>
                    <motion.button
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      onClick={toggleFullscreen}
                      className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
                      title={isFullscreen ? "Exit Standalone Mode" : "Enter Standalone Mode"}
                    >
                      {isFullscreen ? <Minimize2 className="w-3.5 h-3.5 text-brand-purple" /> : <Maximize2 className="w-3.5 h-3.5" />}
                    </motion.button>
                    
                    <motion.button
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      onClick={() => setIsSidebarLocked(!isSidebarLocked)}
                      className={cn(
                        "p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer",
                        isSidebarLocked ? "text-brand-purple bg-brand-purple/10" : ""
                      )}
                      title={isSidebarLocked ? "Unlock Sidebar Autohide" : "Pin Sidebar Open"}
                    >
                      {isSidebarLocked ? <Pin className="w-3.5 h-3.5" /> : <PinOff className="w-3.5 h-3.5" />}
                    </motion.button>
                  </>
                )}
              </div>
            )}
          </AnimatePresence>
        </div>

        <nav className="flex-1 w-full px-2.5 md:px-3 py-4 md:py-6 space-y-1 overflow-y-auto overflow-x-hidden scrollbar-hide">
          {NAV_ITEMS.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => { if (isMobile) setIsMobileSidebarOpen(false); }}
                className={cn(
                  "flex items-center gap-3.5 px-3 py-3 rounded-2xl transition-all duration-300 relative overflow-hidden group/link",
                  isActive 
                    ? "text-white bg-white/[0.08] shadow-[inset_0_1px_1px_rgba(255,255,255,0.1)] border border-white/5" 
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                )}
              >
                 {isActive && (
                    <motion.div 
                      layoutId="active-spatial-nav"
                      className="absolute inset-[1px] bg-brand-purple/15 rounded-[14px]"
                      transition={{ type: "spring", stiffness: 350, damping: 25 }}
                    />
                 )}
                <item.icon className={cn(
                  "w-5 h-5 relative z-10 shrink-0 transition-transform group-hover/link:scale-105",
                  isActive ? "text-brand-purple text-glow" : "text-gray-400"
                )} />
                <AnimatePresence>
                  {showExpandedContent && (
                    <motion.span
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -8 }}
                      className="font-medium text-[11px] whitespace-nowrap relative z-10 font-sans tracking-wide"
                    >
                      {item.label}
                    </motion.span>
                  )}
                </AnimatePresence>
              </Link>
            )
          })}
        </nav>

        <div className="p-3 md:p-4 border-t border-white/[0.06] space-y-2">
             <Link
                to="/settings"
                onClick={() => { if (isMobile) setIsMobileSidebarOpen(false); }}
                className={cn(
                  "flex items-center gap-3.5 px-3 py-2.5 rounded-2xl transition-colors group",
                  location.pathname === '/settings' ? "bg-white/10 text-white" : "text-gray-400 hover:text-white hover:bg-white/5"
                )}
              >
                <Settings className="w-5 h-5 flex-shrink-0" />
                <AnimatePresence>
                   {showExpandedContent && (
                     <motion.span
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="font-medium text-xs whitespace-nowrap block"
                     >System Preferences</motion.span>
                   )}
                </AnimatePresence>
             </Link>

             {/* Profile Account Card */}
             <div className="pt-2 border-t border-white/5">
                <div className={cn(
                  "flex items-center rounded-2xl p-2 bg-white/5 border border-white/5 space-x-3 overflow-hidden",
                  !showExpandedContent ? "justify-center p-1.5" : ""
                )}>
                  <img 
                    src={getAvatarUrl()} 
                    alt="User Avatar" 
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full border border-white/10 bg-white/5 shadow-inner flex-shrink-0" 
                  />
                  
                  <AnimatePresence>
                    {showExpandedContent && (
                      <motion.div 
                        initial={{ opacity: 0, width: 0 }}
                        animate={{ opacity: 1, width: 'auto' }}
                        exit={{ opacity: 0, width: 0 }}
                        className="flex-1 min-w-0 font-sans"
                      >
                        <h4 className="text-xs font-serif text-white truncate leading-snug">{getName()}</h4>
                        <p className="text-[9px] font-mono text-gray-500 truncate leading-tight">{getEmail()}</p>
                        <div className="mt-1 flex items-center gap-1.5">
                          {user ? (
                            <span className="inline-flex items-center px-1.5 py-0.5 rounded-md bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[8px] font-mono uppercase tracking-wide">
                              <Cloud className="w-2.5 h-2.5 mr-0.5" /> Synced
                            </span>
                          ) : (
                            <span className="inline-flex items-center px-1.5 py-0.5 rounded-md bg-amber-500/10 border border-amber-500/20 text-amber-400 text-[8px] font-mono uppercase tracking-wide">
                              <CloudOff className="w-2.5 h-2.5 mr-0.5" /> Guest
                            </span>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Sign out Action Button */}
                  <AnimatePresence>
                    {showExpandedContent && (
                      <motion.button
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={async () => {
                          if (isMobile) setIsMobileSidebarOpen(false);
                          await logout();
                          navigate({ to: '/auth' });
                        }}
                        className="p-2 rounded-xl text-gray-400 hover:text-rose-400 hover:bg-white/5 transition-colors"
                        title="Disconnect sequence"
                      >
                        <LogOut className="w-4 h-4" />
                      </motion.button>
                    )}
                  </AnimatePresence>
                </div>

                {!showExpandedContent && (
                  <button
                    onClick={async () => {
                      if (isMobile) setIsMobileSidebarOpen(false);
                      await logout();
                      navigate({ to: '/auth' });
                    }}
                    className="w-full mt-2 p-2 rounded-xl text-gray-400 hover:text-rose-400 hover:bg-white/5 transition-colors flex justify-center"
                    title="Disconnect sequence"
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                )}
             </div>
        </div>
      </motion.aside>

      {/* Main Content Pane */}
      <main className={cn(
        "flex-1 relative z-10 w-full max-w-full transition-all duration-300 ease-in-out min-h-screen overflow-x-hidden",
        "pb-8",
        isMobile 
          ? "pt-[64px] pl-0" 
          : (isExpanded ? "pl-[260px]" : "pl-[104px]")
      )}>
        <div className="max-w-7xl mx-auto p-3 sm:p-5 md:p-8 min-h-full">
           <Outlet />
        </div>
      </main>
    </div>
  );

  return (
    <>
      {mainContent}
      <PDFSidebarPanel />
      <FloatingPomodoro />
    </>
  );
}
