import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useNavigate } from '@tanstack/react-router';
import { GlassCard } from '@/components/GlassCard';
import { GlowButton } from '@/components/GlowButton';
import { Sparkles, ArrowRight, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function Auth() {
  const { user, loginWithGoogle, continueAsGuest } = useAuth();
  const navigate = useNavigate();

  const [authError, setAuthError] = useState<string | null>(null);
  const [isDomainError, setIsDomainError] = useState(false);
  const [isSigningIn, setIsSigningIn] = useState(false);

  // Redirect if already authenticated
  useEffect(() => {
    if (user) {
      navigate({ to: '/' });
    }
  }, [user, navigate]);

  const handleGoogleSignIn = async () => {
    setIsSigningIn(true);
    setAuthError(null);
    setIsDomainError(false);

    try {
      const { error } = await loginWithGoogle(false);
      if (error) {
        const errorMsg = error.message || 'Google Sign-In failed';
        setAuthError(errorMsg);
        
        // Detect Firebase unauthorized-domain error
        const isDomainErr = error.code === 'auth/unauthorized-domain' || 
                            error.message?.includes('unauthorized-domain') ||
                            error.message?.includes('authDomain') ||
                            error.message?.includes('unauthorized');
        if (isDomainErr) {
          setIsDomainError(true);
        }
        setIsSigningIn(false);
      } else {
        navigate({ to: '/' });
      }
    } catch (err: any) {
      setAuthError(err.message || 'Google authentication failed');
      setIsSigningIn(false);
    }
  };



  const handleGuestEntry = () => {
    continueAsGuest();
    navigate({ to: '/' });
  };

  return (
    <div className="min-h-[90vh] flex flex-col items-center justify-center py-12 px-4 relative overflow-hidden select-none">
      
      {/* Decorative Fluid Blur Backdrops */}
      <div className="absolute top-[15%] left-[10%] w-[450px] h-[450px] rounded-full bg-brand-purple/10 blur-[130px] pointer-events-none animate-pulse duration-[8000ms]" />
      <div className="absolute bottom-[15%] right-[10%] w-[450px] h-[450px] rounded-full bg-brand-indigo/10 blur-[130px] pointer-events-none animate-pulse duration-[8000ms]" />

      {/* Main Google Auth Card Frame */}
      <div className="w-full max-w-[450px] space-y-6 z-10">
        
        {/* StudyVibe Header Banner */}
        <div className="text-center space-y-3">
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/[0.03] border border-white/5 shadow-[0_0_15px_rgba(255,255,255,0.02)]"
          >
            <Sparkles className="w-3.5 h-3.5 text-brand-purple animate-pulse" />
            <span className="mono-label text-[10px] text-gray-400 uppercase tracking-widest font-semibold font-mono">Google Authentication Sync</span>
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl serif-title tracking-tight text-white italic text-center font-bold font-serif"
          >
            StudyVibe
          </motion.h1>
        </div>

        {/* Real Google Account Chooser Card */}
        <GlassCard className="relative p-7 border-white/10 bg-[#0d0d11]/80 glow-indigo shadow-2xl overflow-hidden rounded-[28px] min-h-[300px] flex flex-col justify-between">
          
          {/* Top Google colored trim */}
          <div className="absolute top-0 left-0 right-0 h-[3px] flex">
            <div className="flex-1 bg-[#4285F4]"></div>
            <div className="flex-1 bg-[#EA4335]"></div>
            <div className="flex-1 bg-[#FBBC05]"></div>
            <div className="flex-1 bg-[#34A853]"></div>
          </div>

          <AnimatePresence mode="wait">
            {isSigningIn ? (
              /* Google Sign-in Loading overlay */
              <motion.div 
                key="loading-screen"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-6"
              >
                {/* Authentic 4-color rotating Google Spinner */}
                <div className="relative w-14 h-14">
                  <div className="absolute inset-0 rounded-full border-4 border-white/10"></div>
                  <div className="absolute inset-0 rounded-full border-4 border-t-[#4285F4] border-r-[#EA4335] border-b-[#FBBC05] border-l-[#34A853] animate-spin"></div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-lg font-medium text-white tracking-tight">Signing you in...</h3>
                  <p className="text-xs text-gray-400 font-mono">
                    Connecting your secure Google Account to StudyVibe
                  </p>
                </div>
              </motion.div>
            ) : (
              /* Authentic Google Sign-in Trigger Screen */
              <motion.div
                key="account-trigger"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1 flex flex-col justify-between"
              >
                <div>
                  {/* Google colorful logo */}
                  <div className="flex justify-center mb-4 mt-2">
                    <svg className="w-10 h-10" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FBBC05"/>
                      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#EA4335"/>
                    </svg>
                  </div>

                  <div className="space-y-1 text-center mb-6">
                    <h2 className="text-xl font-medium text-white tracking-tight">Welcome to StudyVibe</h2>
                    <p className="text-xs text-gray-400">Sign in securely with your Google account</p>
                  </div>

                  {authError && (
                    <div className="p-3.5 mb-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-mono flex flex-col gap-2.5 animate-in slide-in-from-top-1 duration-200">
                      <div className="flex items-start gap-2 text-left">
                        <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                        <span>{authError}</span>
                      </div>
                      
                      {isDomainError && (
                        <div className="pt-3 border-t border-rose-500/10 mt-2 space-y-2.5 text-left font-sans text-xs text-gray-300 leading-relaxed">
                          <p className="text-[10.5px] text-rose-300 font-medium font-sans">
                            Firebase requires your app's origin domain to be authorized:
                          </p>
                          <ol className="list-decimal list-inside space-y-1.5 text-[10px] text-gray-400 font-sans">
                            <li>Open the <a href="https://console.firebase.google.com/" target="_blank" rel="noopener noreferrer" className="text-indigo-400 hover:underline">Firebase Console</a></li>
                            <li>Go to <strong>Authentication</strong> &gt; <strong>Settings</strong></li>
                            <li>Find the <strong>Authorized domains</strong> registry</li>
                            <li>Add your current hostname (e.g. <code>localhost</code> or your custom local IP)</li>
                          </ol>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Sign In with Google Button */}
                  <div className="pt-2">
                    <GlowButton 
                      onClick={handleGoogleSignIn}
                      className="w-full flex items-center justify-center gap-3 py-3 bg-[#13131a] hover:bg-[#1a1a24] text-white rounded-2xl border border-white/10 transition-all font-sans font-medium text-sm shadow-md"
                    >
                      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FBBC05"/>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#EA4335"/>
                      </svg>
                      <span>Sign in with Google</span>
                    </GlowButton>
                  </div>
                </div>

                <div className="text-[10px] text-gray-500 font-mono text-center pt-6 border-t border-white/5 mt-6 leading-relaxed">
                  StudyVibe connects directly with standard Google APIs to sync your dashboard settings, learning batches, and focus metrics securely.
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </GlassCard>

        {/* Local Guest Mode entry link */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.8 }}
          transition={{ delay: 0.3 }}
          className="text-center space-y-2.5"
        >
          <button 
             onClick={handleGuestEntry}
             className="inline-flex items-center gap-2 group text-xs text-brand-purple hover:text-brand-indigo font-mono font-bold tracking-widest uppercase transition-colors py-2 px-4 rounded-xl hover:bg-white/5 cursor-pointer"
          >
            <span>Continue as Guest</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1.5 transition-transform" />
          </button>
          
          <p className="text-[10px] text-gray-500 font-mono max-w-xs mx-auto leading-relaxed">
            Your playlists, notes, and study stats will be saved locally inside your browser cache.
          </p>
        </motion.div>

      </div>
    </div>
  );
}
