import React, { createContext, useContext, useEffect, useState } from 'react';
import { auth } from '@/lib/firebase';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut 
} from 'firebase/auth';

export interface User {
  id: string;
  email: string;
  user_metadata?: {
    full_name?: string;
    avatar_url?: string;
  };
}

export type Session = any;

export interface Profile {
  id: string;
  email: string;
  isGuest: boolean;
  name: string;
  avatar_url: string;
  syncStatus: 'synced' | 'local' | 'syncing';
}

interface AuthContextType {
  user: User | null;
  guestUser: Profile | null;
  session: Session | null;
  loading: boolean;
  isGuest: boolean;
  loginWithGoogle: () => Promise<{ error: any }>;
  continueAsGuest: (name?: string) => void;
  logout: () => Promise<void>;
  updateGuestProfile: (name: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [guestUser, setGuestUser] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isGuest, setIsGuest] = useState(false);

  // Initialize Auth State
  useEffect(() => {
    // Listen to real Firebase Auth state changes
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        const mappedUser: User = {
          id: firebaseUser.uid,
          email: firebaseUser.email || '',
          user_metadata: {
            full_name: firebaseUser.displayName || 'Learner',
            avatar_url: firebaseUser.photoURL || `https://api.dicebear.com/7.x/notionists/svg?seed=${firebaseUser.email || 'Study'}`
          }
        };
        setUser(mappedUser);
        setSession({ token: 'active-session' });
        setIsGuest(false);
        setGuestUser(null);
      } else {
        setUser(null);
        setSession(null);
        
        // Retrieve guest profile if it exists
        const savedGuest = localStorage.getItem('studyvibe_guest');
        if (savedGuest) {
          setGuestUser(JSON.parse(savedGuest));
          setIsGuest(true);
        } else {
          setGuestUser(null);
          setIsGuest(false);
        }
      }
      setLoading(false);
    }, (error) => {
      console.error('Firebase Auth state change error:', error);
      
      const savedGuest = localStorage.getItem('studyvibe_guest');
      if (savedGuest) {
        setGuestUser(JSON.parse(savedGuest));
        setIsGuest(true);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithGoogle = async () => {
    setLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      
      const userCredential = await signInWithPopup(auth, provider);
      const mappedUser: User = {
        id: userCredential.user.uid,
        email: userCredential.user.email || '',
        user_metadata: {
          full_name: userCredential.user.displayName || 'Learner',
          avatar_url: userCredential.user.photoURL || `https://api.dicebear.com/7.x/notionists/svg?seed=${userCredential.user.email || 'Study'}`
        }
      };
      
      setUser(mappedUser);
      setSession({ token: 'firebase-token' });
      setIsGuest(false);
      setGuestUser(null);
      localStorage.removeItem('studyvibe_guest');
      setLoading(false);
      return { error: null };
    } catch (err: any) {
      console.error("Google authentication failed:", err);
      setLoading(false);
      return { error: err };
    }
  };

  const continueAsGuest = (customName?: string) => {
    const guestId = 'guest_' + Math.random().toString(36).substring(2, 11);
    const resolvedName = customName || 'Scholar ' + guestId.substring(6, 10).toUpperCase();
    
    const configuredGuest: Profile = {
      id: guestId,
      email: 'guest@studyvibe.local',
      isGuest: true,
      name: resolvedName,
      avatar_url: `https://api.dicebear.com/7.x/notionists/svg?seed=${guestId}`,
      syncStatus: 'local',
    };

    localStorage.setItem('studyvibe_guest', JSON.stringify(configuredGuest));
    
    setGuestUser(configuredGuest);
    setUser(null);
    setSession(null);
    setIsGuest(true);
  };

  const logout = async () => {
    setLoading(true);
    try {
      await signOut(auth);
    } catch (e) {
      console.error("Firebase SignOut error:", e);
    }
    setUser(null);
    setSession(null);
    setGuestUser(null);
    setIsGuest(false);
    localStorage.removeItem('studyvibe_guest');
    setLoading(false);
  };

  const updateGuestProfile = (name: string) => {
    if (guestUser) {
      const updated = { ...guestUser, name };
      localStorage.setItem('studyvibe_guest', JSON.stringify(updated));
      setGuestUser(updated);
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      guestUser,
      session,
      loading,
      isGuest,
      loginWithGoogle,
      continueAsGuest,
      logout,
      updateGuestProfile,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
