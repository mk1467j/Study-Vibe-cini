import React, { createContext, useContext, useState, useEffect, useRef } from 'react';

export interface MusicTrack {
  id: string;
  title: string;
  artist: string;
  source: 'url' | 'youtube' | 'spotify';
  type: 'ambient' | 'lofi' | 'academic' | 'imported';
  url: string; // URL, Video ID, or Spotify URI
  duration?: string;
  cover?: string;
}

export interface Playlist {
  id: string;
  name: string;
  description: string;
  tracks: MusicTrack[];
  isCustom?: boolean;
}

interface MusicContextType {
  playlists: Playlist[];
  activePlaylistId: string;
  currentTrackIndex: number;
  currentTrack: MusicTrack | null;
  isPlaying: boolean;
  isMuted: boolean;
  volume: number; // 0 - 100
  progress: number; // 0 - 100
  duration: number; // seconds
  currentTime: number; // seconds
  isShuffle: boolean;
  isLoop: boolean;
  isVideoMode: boolean;
  // Actions
  playTrack: (playlistId: string, trackIndex: number) => void;
  togglePlay: () => void;
  nextTrack: () => void;
  prevTrack: () => void;
  toggleMute: () => void;
  setVolume: (val: number) => void;
  seek: (percent: number) => void;
  toggleShuffle: () => void;
  toggleLoop: () => void;
  setIsVideoMode: (val: boolean) => void;
  importLink: (url: string) => Promise<boolean>;
  deleteTrack: (playlistId: string, trackId: string) => void;
  deletePlaylist: (playlistId: string) => void;
  createPlaylist: (name: string, description?: string) => void;
  addTrackToPlaylist: (playlistId: string, track: Omit<MusicTrack, 'id'>) => void;
  renamePlaylist: (playlistId: string, newName: string) => void;
  activePlaylist: Playlist | null;
  setYoutubePlayer: (player: any) => void;
}

const MusicContext = createContext<MusicContextType | undefined>(undefined);

export const parseImportLink = (url: string): Omit<MusicTrack, 'id'> | null => {
  const trimmed = url.trim();
  
  const ytVideoReg = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
  const ytPlaylistReg = /[?&]list=([^"&?\/\s]+)/;
  
  const spotifyReg = /spotify(?:\/|:)(track|playlist|album|episode|show)(?:\/|:)([a-zA-Z0-9]+)/;
  const spotifyUrlReg = /open\.spotify\.com\/(track|playlist|album|episode|show)\/([a-zA-Z0-9]+)/;

  const ytVideoMatch = trimmed.match(ytVideoReg);
  const ytPlaylistMatch = trimmed.match(ytPlaylistReg);
  const spotifyUrlMatch = trimmed.match(spotifyUrlReg);
  const spotifyMatch = trimmed.match(spotifyReg);

  if (ytPlaylistMatch) {
    return {
      title: `YT Playlist ${ytPlaylistMatch[1].substring(0, 8)}...`,
      artist: 'YouTube Playlist',
      source: 'youtube',
      type: 'imported',
      url: ytPlaylistMatch[1],
      duration: 'Playlist',
      cover: `https://img.youtube.com/vi/${ytPlaylistMatch[1]}/mqdefault.jpg`
    };
  } else if (ytVideoMatch) {
    return {
      title: `YT Video ${ytVideoMatch[1].substring(0, 8)}...`,
      artist: 'YouTube Video',
      source: 'youtube',
      type: 'imported',
      url: ytVideoMatch[1],
      duration: 'Live',
      cover: `https://img.youtube.com/vi/${ytVideoMatch[1]}/mqdefault.jpg`
    };
  } else if (spotifyUrlMatch) {
    const type = spotifyUrlMatch[1];
    return {
      title: `${type.toUpperCase()} from Spotify`,
      artist: 'Spotify Sync',
      source: 'spotify',
      type: 'imported',
      url: `spotify:${type}:${spotifyUrlMatch[2]}`,
      duration: 'Active',
      cover: '🟢'
    };
  } else if (spotifyMatch) {
    const type = spotifyMatch[1];
    return {
      title: `${type.toUpperCase()} from Code`,
      artist: 'Spotify Link',
      source: 'spotify',
      type: 'imported',
      url: trimmed,
      duration: 'Active',
      cover: '🟢'
    };
  } else if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
    const parts = trimmed.split('/');
    const name = parts[parts.length - 1].split('?')[0] || 'Imported Audio';
    return {
      title: decodeURIComponent(name).replace(/\+/g, ' '),
      artist: 'Web Stream',
      source: 'url',
      type: 'imported',
      url: trimmed,
      duration: 'Audio',
      cover: '🔗'
    };
  }

  return null;
};

export const MusicProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [playlists, setPlaylists] = useState<Playlist[]>(() => {
    const saved = localStorage.getItem('studyvibe_playlists');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Remove the all-ambient preset playlist if it is cached
        const filtered = parsed.filter((p: Playlist) => p.id !== 'all-ambient');
        if (filtered.length > 0) return filtered;
      } catch (e) {}
    }
    return [
      { id: 'imported', name: 'My Music', description: 'Imported tracks from YouTube and Spotify', tracks: [], isCustom: false }
    ];
  });

  const [activePlaylistId, setActivePlaylistId] = useState(() => {
    const saved = localStorage.getItem('studyvibe_music_playlist_id');
    return saved && saved !== 'all-ambient' ? saved : 'imported';
  });

  const [currentTrackIndex, setCurrentTrackIndex] = useState(() => {
    const val = localStorage.getItem('studyvibe_music_track_idx');
    return val !== null ? parseInt(val, 10) : 0;
  });

  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(() => {
    return localStorage.getItem('studyvibe_music_muted') === 'true';
  });

  const [volume, setVolumeState] = useState(() => {
    const val = localStorage.getItem('studyvibe_music_vol');
    return val !== null ? parseInt(val, 10) : 60;
  });

  const [isShuffle, setIsShuffle] = useState(() => {
    return localStorage.getItem('studyvibe_music_shuffle') === 'true';
  });

  const [isLoop, setIsLoop] = useState(() => {
    return localStorage.getItem('studyvibe_music_loop') === 'true';
  });

  const [isVideoMode, setIsVideoModeState] = useState(() => {
    return localStorage.getItem('studyvibe_music_video_mode') === 'true';
  });

  const [currentTime, setCurrentTime] = useState(() => {
    const val = localStorage.getItem('studyvibe_music_current_time');
    return val !== null ? parseFloat(val) : 0;
  });
  const [duration, setDuration] = useState(0);
  const [progress, setProgress] = useState(0);

  // References
  const isInitialMount = useRef(true);
  const hasRestoredTime = useRef(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const ytPlayerRef = useRef<any>(null);
  const lastPlayedTrackIdRef = useRef<string | null>(null);

  // Active indices resolve
  const activePlaylist = playlists.find(p => p.id === activePlaylistId) || playlists[0] || null;
  const currentTrack = (activePlaylist && activePlaylist.tracks[currentTrackIndex]) || null;

  // Persist settings
  useEffect(() => {
    localStorage.setItem('studyvibe_playlists', JSON.stringify(playlists));
  }, [playlists]);

  useEffect(() => {
    localStorage.setItem('studyvibe_music_playlist_id', activePlaylistId);
    setCurrentTrackIndex(0);
  }, [activePlaylistId]);

  useEffect(() => {
    localStorage.setItem('studyvibe_music_video_mode', isVideoMode.toString());
    
    // Dynamically adjust playback quality to save data
    if (ytPlayerRef.current && typeof ytPlayerRef.current.setPlaybackQuality === 'function') {
      try {
        ytPlayerRef.current.setPlaybackQuality(isVideoMode ? 'medium' : 'small');
      } catch (e) {}
    }

    if (isPlaying) {
      triggerPlayback();
    }
  }, [isVideoMode]);

  useEffect(() => {
    localStorage.setItem('studyvibe_music_track_idx', currentTrackIndex.toString());
    
    if (isInitialMount.current) {
      isInitialMount.current = false;
      const savedTime = localStorage.getItem('studyvibe_music_current_time');
      if (savedTime) {
        const t = parseFloat(savedTime);
        if (t > 0) {
          setCurrentTime(t);
          setProgress(0);
        }
      }
    } else {
      setCurrentTime(0);
      setProgress(0);
      setDuration(0);
      hasRestoredTime.current = true;
    }
    
    if (isPlaying) {
      triggerPlayback();
    }
  }, [currentTrackIndex]);

  useEffect(() => {
    localStorage.setItem('studyvibe_music_muted', isMuted.toString());
    updateVolume();
  }, [isMuted]);

  useEffect(() => {
    localStorage.setItem('studyvibe_music_vol', volume.toString());
    updateVolume();
  }, [volume]);

  useEffect(() => {
    localStorage.setItem('studyvibe_music_shuffle', isShuffle.toString());
  }, [isShuffle]);

  useEffect(() => {
    localStorage.setItem('studyvibe_music_loop', isLoop.toString());
  }, [isLoop]);

  // Unified HTML5 Audio hooks
  useEffect(() => {
    const handleTimeUpdate = () => {
      const isNativeAudio = currentTrack?.source === 'url';

      if (audioRef.current && isNativeAudio) {
        const t = audioRef.current.currentTime;
        const d = audioRef.current.duration || 0;
        setCurrentTime(t);
        setDuration(d);
        setProgress(d > 0 ? (t / d) * 100 : 0);
        localStorage.setItem('studyvibe_music_current_time', t.toString());
      }
    };

    const handleEnded = () => {
      if (isLoop) {
        if (audioRef.current) {
          audioRef.current.currentTime = 0;
          audioRef.current.play().catch(() => {});
        }
      } else {
        nextTrack();
      }
    };

    if (!audioRef.current) {
      audioRef.current = new Audio();
    }

    const audio = audioRef.current;
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
    };
  }, [currentTrack, isLoop, isVideoMode]);

  // YouTube active status ticks
  useEffect(() => {
    let timer: any;
    if (isPlaying && currentTrack?.source === 'youtube') {
      timer = setInterval(() => {
        if (ytPlayerRef.current) {
          try {
            if (typeof ytPlayerRef.current.getCurrentTime === 'function') {
              const t = ytPlayerRef.current.getCurrentTime() || 0;
              const d = ytPlayerRef.current.getDuration() || 0;
              if (d > 0) {
                setCurrentTime(t);
                setDuration(d);
                setProgress((t / d) * 100);
                localStorage.setItem('studyvibe_music_current_time', t.toString());
              }
            }
          } catch (e) {}
        }
      }, 500);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isPlaying, currentTrack]);

  // Main playback manager effect
  useEffect(() => {
    if (isPlaying) {
      triggerPlayback();
    } else {
      pausePlayback();
    }
  }, [isPlaying, currentTrackIndex]);

  const setYoutubePlayer = (player: any) => {
    ytPlayerRef.current = player;
    updateVolume();
    if (player) {
      try {
        if (isPlaying && currentTrack?.source === 'youtube') {
          player.playVideo();
        }
      } catch (e) {}
    }
  };

  const updateVolume = () => {
    const activeVolume = isMuted ? 0 : volume;
    if (audioRef.current) {
      audioRef.current.volume = activeVolume / 100;
    }
    if (ytPlayerRef.current && typeof ytPlayerRef.current.setVolume === 'function') {
      try {
        ytPlayerRef.current.setVolume(activeVolume);
      } catch (e) {}
    }
  };

  const unblockAudio = () => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
    }
  };

  const playTrack = (playlistId: string, trackIndex: number) => {
    unblockAudio();
    setActivePlaylistId(playlistId);
    setCurrentTrackIndex(trackIndex);
    setIsPlaying(true);
  };

  const togglePlay = () => {
    unblockAudio();
    setIsPlaying(prev => !prev);
  };

  const nextTrack = () => {
    if (!activePlaylist || activePlaylist.tracks.length === 0) return;
    if (isShuffle) {
      const idx = Math.floor(Math.random() * activePlaylist.tracks.length);
      setCurrentTrackIndex(idx);
    } else {
      setCurrentTrackIndex(prev => (prev + 1) % activePlaylist.tracks.length);
    }
    setProgress(0);
    setCurrentTime(0);
  };

  const prevTrack = () => {
    if (!activePlaylist || activePlaylist.tracks.length === 0) return;
    setCurrentTrackIndex(prev => (prev - 1 + activePlaylist.tracks.length) % activePlaylist.tracks.length);
    setProgress(0);
    setCurrentTime(0);
  };

  const toggleMute = () => {
    setIsMuted(prev => !prev);
  };

  const setVolume = (val: number) => {
    setVolumeState(Math.max(0, Math.min(100, val)));
  };

  const seek = (percent: number) => {
    const resolved = Math.max(0, Math.min(100, percent));
    const isNativeAudio = currentTrack?.source === 'url';

    if (isNativeAudio && audioRef.current && duration > 0) {
      const targetTime = (resolved / 100) * duration;
      audioRef.current.currentTime = targetTime;
      setCurrentTime(targetTime);
      setProgress(resolved);
    } else if (currentTrack?.source === 'youtube' && ytPlayerRef.current) {
      try {
        const ytDuration = ytPlayerRef.current.getDuration() || 0;
        if (ytDuration > 0) {
          const targetTime = (resolved / 100) * ytDuration;
          ytPlayerRef.current.seekTo(targetTime, true);
          setProgress(resolved);
        }
      } catch (e) {}
    } else {
      setProgress(resolved);
    }
  };

  const toggleShuffle = () => {
    setIsShuffle(prev => !prev);
  };

  const toggleLoop = () => {
    setIsLoop(prev => !prev);
  };

  const setIsVideoMode = (val: boolean) => {
    setIsVideoModeState(val);
  };

  const importLink = async (url: string): Promise<boolean> => {
    const parsed = parseImportLink(url);
    if (!parsed) return false;

    const isYoutube = parsed.source === 'youtube';

    if (isYoutube) {
      try {
        const res = await fetch(`/api/playlist?url=${encodeURIComponent(url)}`);
        if (!res.ok) throw new Error("Scraper returned error status");
        
        const data = await res.json();
        
        if (data && Array.isArray(data.videos) && data.videos.length > 0) {
          if (data.isPlaylist) {
            // Batch playlist style import: Create a NEW named playlist in sidebar!
            const playlistId = `custom-pl-${Date.now()}`;
            const playlistTracks: MusicTrack[] = data.videos.map((vid: any, idx: number) => ({
              id: `imported-${vid.id}-${Date.now()}-${idx}`,
              title: vid.title,
              artist: data.title || 'YouTube Registry',
              source: 'youtube',
              type: 'imported',
              url: vid.id,
              duration: vid.duration,
              cover: `https://img.youtube.com/vi/${vid.id}/mqdefault.jpg`
            }));

            const freshPlaylist: Playlist = {
              id: playlistId,
              name: data.title || `Playlist #${playlists.length + 1}`,
              description: 'Imported YouTube playlist',
              tracks: playlistTracks,
              isCustom: true
            };

            setPlaylists(prev => [...prev, freshPlaylist]);
            setActivePlaylistId(playlistId);
            setCurrentTrackIndex(0);
          } else {
            // Single video import: Add directly into "imported"
            const vid = data.videos[0];
            const freshTrack: MusicTrack = {
              id: `imported-${vid.id}-${Date.now()}`,
              title: vid.title || data.title || `YouTube Video`,
              artist: 'YouTube Video',
              source: 'youtube',
              type: 'imported',
              url: vid.id,
              duration: vid.duration,
              cover: `https://img.youtube.com/vi/${vid.id}/mqdefault.jpg`
            };

            setPlaylists(prev => {
              return prev.map(p => {
                if (p.id === 'imported') {
                  const existingUrls = new Set(p.tracks.map(t => t.url));
                  if (existingUrls.has(freshTrack.url)) return p;
                  return {
                    ...p,
                    tracks: [freshTrack, ...p.tracks]
                  };
                }
                return p;
              });
            });
            setActivePlaylistId('imported');
            setCurrentTrackIndex(0);
          }
        } else {
          addSingleParsedTrack(parsed);
        }
      } catch (err) {
        console.warn("Failed to fetch playlist details from scraper, adding parsed fallback:", err);
        addSingleParsedTrack(parsed);
      }
    } else {
      addSingleParsedTrack(parsed);
    }

    return true;
  };

  const addSingleParsedTrack = (parsed: Omit<MusicTrack, 'id'>) => {
    const freshTrack: MusicTrack = {
      id: `imported-${Date.now()}`,
      ...parsed
    };
    setPlaylists(prev => {
      return prev.map(p => {
        if (p.id === 'imported') {
          const existingUrls = new Set(p.tracks.map(t => t.url));
          if (existingUrls.has(freshTrack.url)) return p;
          return {
            ...p,
            tracks: [freshTrack, ...p.tracks]
          };
        }
        return p;
      });
    });
    setActivePlaylistId('imported');
    setCurrentTrackIndex(0);
  };

  const deleteTrack = (playlistId: string, trackId: string) => {
    setPlaylists(prev => {
      return prev.map(p => {
        if (p.id === playlistId) {
          const filtered = p.tracks.filter(t => t.id !== trackId);
          return { ...p, tracks: filtered };
        }
        return p;
      });
    });

    if (activePlaylistId === playlistId) {
      setCurrentTrackIndex(0);
      setProgress(0);
      setCurrentTime(0);
    }
  };

  const deletePlaylist = (playlistId: string) => {
    if (playlistId === 'imported') return;
    setPlaylists(prev => prev.filter(p => p.id !== playlistId));
    if (activePlaylistId === playlistId) {
      setActivePlaylistId('imported');
      setCurrentTrackIndex(0);
      setProgress(0);
      setCurrentTime(0);
    }
  };

  const renamePlaylist = (playlistId: string, newName: string) => {
    if (!newName.trim()) return;
    setPlaylists(prev => {
      return prev.map(p => {
        if (p.id === playlistId) {
          return { ...p, name: newName.trim() };
        }
        return p;
      });
    });
  };

  const createPlaylist = (name: string, description: string = '') => {
    const id = `custom-pl-${Date.now()}`;
    setPlaylists(prev => [
      ...prev,
      { id, name, description, tracks: [], isCustom: true }
    ]);
  };

  const addTrackToPlaylist = (playlistId: string, track: Omit<MusicTrack, 'id'>) => {
    setPlaylists(prev => {
      return prev.map(p => {
        if (p.id === playlistId) {
          const fresh: MusicTrack = {
            id: `track-${Date.now()}`,
            ...track
          };
          return { ...p, tracks: [...p.tracks, fresh] };
        }
        return p;
      });
    });
  };

  const triggerPlayback = () => {
    if (!currentTrack) return;

    const isSameTrack = lastPlayedTrackIdRef.current === currentTrack.id;

    if (currentTrack.source === 'url') {
      // Stop YouTube player if active
      if (ytPlayerRef.current && typeof ytPlayerRef.current.pauseVideo === 'function') {
        try { ytPlayerRef.current.pauseVideo(); } catch (e) {}
      }

      if (!audioRef.current) {
        audioRef.current = new Audio();
      }

      if (!isSameTrack || audioRef.current.src !== currentTrack.url) {
        audioRef.current.src = currentTrack.url;
        
        const savedTime = localStorage.getItem('studyvibe_music_current_time');
        const t = !hasRestoredTime.current && savedTime ? parseFloat(savedTime) : 0;
        hasRestoredTime.current = true;
        
        audioRef.current.currentTime = t;
        setCurrentTime(t);
      }

      audioRef.current.loop = isLoop;
      audioRef.current.volume = (isMuted ? 0 : volume) / 100;

      audioRef.current.play().catch(e => {
        console.warn("Audio autoplay blocked by browser policy:", e);
      });

      lastPlayedTrackIdRef.current = currentTrack.id;
    } else if (currentTrack.source === 'youtube') {
      const videoId = currentTrack.url;

      // Stop native audio player
      if (audioRef.current) {
        try { audioRef.current.pause(); } catch (e) {}
      }

      if (ytPlayerRef.current) {
        try {
          if (typeof ytPlayerRef.current.setVolume === 'function') {
            ytPlayerRef.current.setVolume(isMuted ? 0 : volume);
          }

          if (isSameTrack) {
            if (typeof ytPlayerRef.current.playVideo === 'function') {
              ytPlayerRef.current.playVideo();
            }
          } else {
            const savedTime = localStorage.getItem('studyvibe_music_current_time');
            const t = !hasRestoredTime.current && savedTime ? parseFloat(savedTime) : 0;
            hasRestoredTime.current = true;

            if (typeof ytPlayerRef.current.loadVideoById === 'function') {
              ytPlayerRef.current.loadVideoById({
                videoId: videoId,
                startSeconds: t
              });
            }
            if (typeof ytPlayerRef.current.playVideo === 'function') {
              ytPlayerRef.current.playVideo();
            }
          }
        } catch (e) {
          console.error("YouTube iframe player failure:", e);
        }
      }

      lastPlayedTrackIdRef.current = currentTrack.id;
    }
  };

  const pausePlayback = () => {
    if (audioRef.current) {
      try { audioRef.current.pause(); } catch (e) {}
    }
    if (ytPlayerRef.current && typeof ytPlayerRef.current.pauseVideo === 'function') {
      try { ytPlayerRef.current.pauseVideo(); } catch (e) {}
    }
  };

  return (
    <MusicContext.Provider value={{
      playlists,
      activePlaylistId,
      currentTrackIndex,
      currentTrack,
      isPlaying,
      isMuted,
      volume,
      progress,
      duration,
      currentTime,
      isShuffle,
      isLoop,
      isVideoMode,
      playTrack,
      togglePlay,
      nextTrack,
      prevTrack,
      toggleMute,
      setVolume,
      seek,
      toggleShuffle,
      toggleLoop,
      setIsVideoMode,
      importLink,
      deleteTrack,
      deletePlaylist,
      createPlaylist,
      addTrackToPlaylist,
      renamePlaylist,
      activePlaylist,
      setYoutubePlayer
    }}>
      {children}
    </MusicContext.Provider>
  );
};

export const useMusic = () => {
  const context = useContext(MusicContext);
  if (!context) {
    throw new Error('useMusic must be used within a MusicProvider');
  }
  return context;
};
